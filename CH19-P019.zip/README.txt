CH19-P019: produce IAKESI-CH19-019-art.png, -lettering.png, -text.txt; 1024x1536; preserve exact lettering transcript; no page numbers or reader-visible text inside base artwork.
