CH19-P046: produce IAKESI-CH19-046-art.png, -lettering.png, -text.txt; 1024x1536; preserve exact lettering transcript; no page numbers or reader-visible text inside base artwork.
